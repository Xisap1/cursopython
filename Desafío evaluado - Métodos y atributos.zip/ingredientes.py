masa = ["Tradicional", "Delgada"]
proteico = ["Pollo", "Vacuno", "Carne Vegetal"]
vegetales = ["Tomate", "Aceituna", "Champiñones"]