from django.contrib import admin
from .models import Curso, Evaluacion, Estudiante, Inscripcion

admin.site.register(Curso)
admin.site.register(Evaluacion)
admin.site.register(Estudiante)
admin.site.register(Inscripcion)
